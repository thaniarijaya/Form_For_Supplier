module Proyek{
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;

    opens sample;
}