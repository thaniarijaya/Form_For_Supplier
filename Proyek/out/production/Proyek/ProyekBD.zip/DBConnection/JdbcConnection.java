package DBConnection;

import java.util.Optional;

public class JdbcConnection {
    /*private static final Logger LOGGER =
            Logger.getLogger(JdbcConnection.class.getName());

    private static Optional<Connection> connection = Optional.empty();

    public static Optional<Connection>getConnection(){
        if(connection.isEmpty()){
            String dbType = "jdbc:postgresql";
            String dbURL =
        }
    }*/
}
