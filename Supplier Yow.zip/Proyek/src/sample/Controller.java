package sample;

import DBConnection.Supplier;
import DBConnection.SupplierDao;
import Interface.Dao;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableView;

import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller {
    @FXML
    private TableView<Supplier> tableViewSupplier; // <Object>
    @FXML
    private TableColumn<Supplier, Integer> colID; // <Object, DataType>
    @FXML
    private TableColumn<Supplier, String> colName;
    @FXML
    private TableColumn<Supplier, Integer> colPrice;
    @FXML
    private TableColumn<Supplier, Integer> colPhoneNum;
    @FXML
    private TableColumn<Supplier, String> colEmail;
    @FXML
    private TextField txtNama;
    @FXML
    private TextField txtHarga;
    @FXML
    private TextField txtTelp;
    @FXML
    private TextField txtEmail;

    private static final Dao<Supplier, Integer> sup = new SupplierDao();

    private ObservableList<Supplier> suppliers = FXCollections.observableArrayList();

    private Integer index;

    // Add new data using CustomerDao add(Customer customer)
    @FXML
    void addCustomer(ActionEvent event) {
        Supplier supplier = new Supplier(0, txtNama.getText(), Integer.valueOf(txtHarga.getText()),
                Integer.valueOf(txtTelp.getText()), txtEmail.getText());
        sup.add(supplier).ifPresent(supplier::setIdSup);
        viewAllRecord();
    }

    @FXML
    void getSelected(MouseEvent event) {
        // Get Index of the Selected Row
        index = tableViewSupplier.getSelectionModel().getSelectedIndex();
        // Out of bound checking
        if (index <= -1) {
            return;
        }

        // Fill textField with Customer Data
        txtNama.setText(colName.getCellData(index));
        txtHarga.setText(colPrice.getCellData(index).toString);
        txtTelp.setText(colPhoneNum.getCellData(index).toString());
        txtEmail.setText(colEmail.getCellData(index).toString());
    }

    // Update selected row data using CustomerDao update(Customer customer)
    @FXML
    void updateCustomer(ActionEvent event) {
        // Update by id, value from TextView
        Supplier supplier = new Supplier(colID.getCellData(index), txtNama.getText(),
                Integer.valueOf(txtHarga.getText()), Integer.valueOf(txtTelp.getText()),
                txtEmail.getText());
        sup.update(supplier);
        viewAllRecord();
    }

    // Delete selected row data using CustomerDao delete(int id)
    @FXML
    void deleteCustomer(ActionEvent event) {
        // Delete by id
        sup.delete(colID.getCellData(index));
        viewAllRecord();
    }


    // Get table data using CustomerDao getAll()
    void viewAllRecord() {
        // Set all data from getAll into ObservableList<Customer>
        suppliers.setAll(sup.getAll());
        tableViewSupplier.setItems(suppliers);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialize Table Column
        colID.setCellValueFactory(new PropertyValueFactory<Supplier, Integer>("ID"));
        colName.setCellValueFactory(new PropertyValueFactory<Supplier, String>("Nama"));
        colPrice.setCellValueFactory(new PropertyValueFactory<Supplier, Integer>("Harga Jasa"));
        colEmail.setCellValueFactory(new PropertyValueFactory<Supplier, String>("Nama"));
        colPhoneNum.setCellValueFactory(new PropertyValueFactory<Supplier, Integer>("Nomor Telepon"));

        viewAllRecord();
    }
}
