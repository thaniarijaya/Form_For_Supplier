package DBConnection;

import Interface.Dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SupplierDao implements Dao<Supplier, Integer> {
    private static final Logger LOGGER = Logger.getLogger(SupplierDao.class.getName());

    private final Optional<Connection> connection;
    private static JdbcConnection con;

    public SupplierDao() {
        this.connection = con.getConnection();
    }

    @Override
    public Optional<Supplier> get(int id) {
        // Use the connection of the database
        return connection.flatMap(conn -> {
            Optional<Supplier> customer = Optional.empty();
            String sql = "SELECT * FROM supplier WHERE id_supplier = " + id;

            // Create Statement to execute SQL
            try (Statement statement = conn.createStatement();
                 // ResultSet object is a table of data representing a database result set
                 ResultSet resultSet = statement.executeQuery(sql)) {

                if (resultSet.next()) {
                    String name = resultSet.getString("Nama");
                    Integer price = resultSet.getInt("Harga Jasa");
                    Integer phone = resultSet.getInt("Nomor Telepon");
                    String email = resultSet.getString("Email");

                    customer = Optional.of(
                            new Supplier(id, name, price, phone, email));

                    LOGGER.log(Level.INFO, "Found {0} in database", customer.get());
                }
            } catch (SQLException ex) {
                LOGGER.log(Level.SEVERE, null, ex);
            }
            return customer;
        });
    }

    @Override
    public Collection<Supplier> getAll() {
        Collection<Supplier> suppliers = new ArrayList<>();
        String sql = "SELECT * FROM supplier ORDER BY id_supplier";

        connection.ifPresent(conn -> {
            try (Statement statement = conn.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {

                while (resultSet.next()) {
                    Integer id = resultSet.getInt("ID");
                    String name = resultSet.getString("Nama");
                    Integer price = resultSet.getInt("Harga Jasa");
                    Integer phone = resultSet.getInt("Nomor Telepon");
                    String email = resultSet.getString("Email");

                    Supplier supplier = new Supplier(id, name, price, phone, email);

                    suppliers.add(supplier);

                    LOGGER.log(Level.INFO, "Found {0} in database", supplier);
                }

            } catch (SQLException ex) {
                LOGGER.log(Level.SEVERE, null, ex);
            }
        });
        return suppliers;
    }

    @Override
    public Optional<Integer> add(Supplier supplier) {
        String message = "The supplier to be added should not be null";
        Supplier nonNullSupplier = Objects.requireNonNull(supplier, message);
        String sql = "INSERT INTO "
                + "supplier(nama_supplier, harga_jasa, email_supplier, telp_supplier) "
                + "VALUES(?, ?, ?)";

        return connection.flatMap(conn -> {
            Optional<Integer> generatedId = Optional.empty();

            try (PreparedStatement statement =
                         conn.prepareStatement(
                                 sql,
                                 Statement.RETURN_GENERATED_KEYS)) {

                statement.setString(1, nonNullSupplier.getNameSup());
                statement.setInt(2, nonNullSupplier.getPriceSup());
                statement.setInt(3, nonNullSupplier.getPhoneNumSup());
                statement.setString(4, nonNullSupplier.getEmailSup());

                int numberOfInsertedRows = statement.executeUpdate();

                // Retrieve the auto-generated id
                if (numberOfInsertedRows > 0) {
                    try (ResultSet resultSet = statement.getGeneratedKeys()) {
                        if (resultSet.next()) {
                            generatedId = Optional.of(resultSet.getInt(1));
                        }
                    }
                }

                LOGGER.log(
                        Level.INFO,
                        "{0} created successfully? {1}",
                        new Object[]{nonNullSupplier,
                                (numberOfInsertedRows > 0)});
            } catch (SQLException ex) {
                LOGGER.log(Level.SEVERE, null, ex);
            }
            return generatedId;
        });
    }

    @Override
    public void update(Supplier supplier) {
        String message = "The customer to be updated should not be null";
        Supplier nonNullSupplier = Objects.requireNonNull(supplier, message);
        String sql = "UPDATE supplier "
                + "SET "
                + "nama_supplier = ?, "
                + "harga_jasa = ?, "
                + "telp_supplier = ? "
                + "email_supplier = ? "
                + "WHERE "
                + "id_supplier = ?";

        connection.ifPresent(conn -> {
            try (PreparedStatement statement = conn.prepareStatement(sql)) {

                statement.setString(1, nonNullSupplier.getNameSup());
                statement.setInt(2, nonNullSupplier.getPriceSup());
                statement.setInt(3, nonNullSupplier.getPhoneNumSup());
                statement.setString(4, nonNullSupplier.getEmailSup());
                statement.setInt(5, nonNullSupplier.getIdSup());

                int numberOfUpdatedRows = statement.executeUpdate();

                LOGGER.log(Level.INFO, "Was the supplier updated successfully? {0}",
                        numberOfUpdatedRows > 0);

            } catch (SQLException ex) {
                LOGGER.log(Level.SEVERE, null, ex);
            }
        });
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM supplier WHERE id_supplier = ?";

        connection.ifPresent(conn -> {
            try (PreparedStatement statement = conn.prepareStatement(sql)) {

                statement.setInt(1, id);

                int numberOfDeletedRows = statement.executeUpdate();

                LOGGER.log(Level.INFO, "Was the supplier deleted successfully? {0}",
                        numberOfDeletedRows > 0);

            } catch (SQLException ex) {
                LOGGER.log(Level.SEVERE, null, ex);
            }
        });
    }
}

