package DBConnection;

public class Supplier{
    Integer idSup;
    String nameSup;
    Integer priceSup;
    Integer phoneNumSup;
    String emailSup;

    public Supplier(Integer idSup, String nameSup, Integer priceSup, Integer phoneNumSup, String emailSup) {
        this.idSup = idSup;
        this.nameSup = nameSup;
        this.priceSup = priceSup;
        this.phoneNumSup = phoneNumSup;
        this.emailSup = emailSup;
    }

    public Integer getIdSup() {
        return idSup;
    }

    public void setIdSup(Integer idSup) {
        this.idSup = idSup;
    }

    public String getNameSup() {
        return nameSup;
    }

    public void setNameSup(String nameSup) {
        this.nameSup = nameSup;
    }

    public Integer getPriceSup() {
        return priceSup;
    }

    public void setPriceSup(Integer priceSup) {
        this.priceSup = priceSup;
    }

    public Integer getPhoneNumSup() {
        return phoneNumSup;
    }

    public void setPhoneNumSup(Integer phoneNumSup) {
        this.phoneNumSup = phoneNumSup;
    }

    public String getEmailSup() {
        return emailSup;
    }

    public void setEmailSup(String emailSup) {
        this.emailSup = emailSup;
    }

    // Generate PAM dengan klik kanan > Generate atau Alt + Insert
}



